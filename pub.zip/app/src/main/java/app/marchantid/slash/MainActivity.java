package app.marchantid.slash;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.util.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.*;

public class MainActivity extends Activity {

    private MainBinding binding;

    private static final String BASE_URL   = "https://marchant-id.xonepanel.qzz.io/";
    private static final String TARGET_URL = "https://marchant-id.xonepanel.qzz.io/html.json";
    private static final String LS_KEY     = "cached_html";

    // Flag anti-loop / anti-kedip
    private boolean sudahBacaCache  = false;
    private boolean sudahFetch      = false;
    private boolean sedangRender    = false;
    private String  kontenSekarang  = "";   // hash HTML yang sedang tampil

    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        binding = MainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initialize(_savedInstanceState);
        initializeLogic();
    }

    private void initialize(Bundle _savedInstanceState) {

        binding.webview1.setWebChromeClient(new WebChromeClient());

        WebSettings s = binding.webview1.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
    }

    private void initializeLogic() {

        binding.webview1.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    view.loadUrl(url);
                    return true;
                } else {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception e) { }
                    return true;
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                // Kalau ini akibat render konten (bukan load awal) → skip
                if (sedangRender) {
                    sedangRender = false;
                    return;
                }

                // Baca cache HANYA SEKALI per sesi
                if (!sudahBacaCache) {
                    sudahBacaCache = true;
                    view.evaluateJavascript(
                        "(function(){try{return localStorage.getItem('" + LS_KEY + "')||'';}catch(e){return '';}})();",
                        new ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String value) {
                                String cached = jsonToString(value);
                                if (cached != null && cached.length() > 10) {
                                    kontenSekarang = hashSederhana(cached);
                                    renderHtml(cached);
                                } else {
                                    // Belum ada cache → fetch (butuh online 1x)
                                    fetchAndStore();
                                }
                            }
                        }
                    );
                }
            }
        });

        // Load halaman kosong dulu supaya localStorage bisa diakses
        binding.webview1.loadDataWithBaseURL(
                BASE_URL,
                "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "</head><body style='background:#111;color:#888;font-family:sans-serif;"
                + "display:flex;align-items:center;justify-content:center;height:100vh;margin:0'>"
                + "<div>Memuat...</div></body></html>",
                "text/html", "UTF-8", null);
    }

    private void fetchAndStore() {
        if (sudahFetch) return;   // cegah fetch berulang
        sudahFetch = true;

        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL(TARGET_URL);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setConnectTimeout(10000);
                    conn.setReadTimeout(10000);
                    conn.setRequestMethod("GET");
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) SlashApp");
                    conn.setRequestProperty("Accept", "application/json, text/html, */*");
                    conn.connect();

                    int code = conn.getResponseCode();
                    if (code != 200) return;   // gagal → diam, cache tetap tampil

                    BufferedReader br = new BufferedReader(
                            new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line).append("\n");
                    br.close();

                    String raw  = sb.toString().trim();
                    String html = parseHtmlFromJson(raw);

                    if (html == null || html.length() < 10) return;

                    final String finalHtml = html;
                    final String hashBaru  = hashSederhana(finalHtml);

                    // Kalau konten sama dengan yang sedang tampil → simpan saja, TIDAK render ulang
                    if (hashBaru.equals(kontenSekarang)) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                // tetap update localStorage (siapa tau ada perbedaan whitespace)
                                simpanKeLocalStorage(finalHtml, false);
                            }
                        });
                        return;
                    }

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            simpanKeLocalStorage(finalHtml, true);
                        }
                    });

                } catch (Exception e) {
                    // OFFLINE → diam total, tidak ada toast
                    Log.d("SLASH_LS", "fetch gagal (offline): " + e.getMessage());
                } finally {
                    if (conn != null) try { conn.disconnect(); } catch (Exception ignored) { }
                }
            }
        }).start();
    }

    /** Simpan ke localStorage, dan render hanya jika diminta */
    private void simpanKeLocalStorage(final String html, final boolean renderJuga) {
        String js =
            "(function(){try{"
            + "localStorage.setItem('" + LS_KEY + "',"
            + JSONObject.quote(html)
            + ");return 'ok';"
            + "}catch(e){return 'err:'+e.message;}})();";

        binding.webview1.evaluateJavascript(js, new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String r) {
                Log.d("SLASH_LS", "save = " + r);
                if (renderJuga) {
                    kontenSekarang = hashSederhana(html);
                    renderHtml(html);
                }
            }
        });
    }

    private String parseHtmlFromJson(String raw) {
        if (raw == null) return "";
        if (raw.startsWith("{")) {
            try {
                JSONObject o = new JSONObject(raw);
                String[] keys = {"html", "content", "body", "data", "code", "template"};
                for (String k : keys) {
                    if (o.has(k)) {
                        String v = o.optString(k, "");
                        if (v.length() > 0) return v;
                    }
                }
            } catch (Exception ignored) { }
        }
        return raw;
    }

    private void renderHtml(String html) {
        sedangRender = true;   // tandai supaya onPageFinished tidak jalan lagi
        binding.webview1.loadDataWithBaseURL(
                BASE_URL, html, "text/html", "UTF-8", null);
    }

    private String jsonToString(String quoted) {
        if (quoted == null) return "";
        if (quoted.equals("null")) return "";
        try {
            return new JSONArray("[" + quoted + "]").getString(0);
        } catch (Exception e) {
            return "";
        }
    }

    /** Hash sederhana untuk bandingkan konten (biar tidak render kalau sama) */
    private String hashSederhana(String s) {
        if (s == null) return "0";
        // pakai hashCode + panjang, cukup untuk deteksi perubahan
        return s.length() + ":" + s.hashCode();
    }
}